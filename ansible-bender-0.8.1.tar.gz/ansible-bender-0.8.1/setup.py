#!/usr/bin/python3

import os

import setuptools

setuptools.setup(use_scm_version=True)
